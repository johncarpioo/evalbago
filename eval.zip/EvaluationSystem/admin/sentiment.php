<?php include'db_connect.php' ?>
 <link rel="stylesheet" href="./css/faclist.css">
<div class="subs">

<style>



table,th,td{
    border: 1px solid #ffdb0d;
    border-collapse: collapse;
   

  }
  th,td{
    padding: 9px;
    font-weight: bold;
    font-size: 15px;

    
  }
  th{
    text-align: center;
    font-size: 17px;
 
  }
  table{
    width: 100%;
    font-family: helvetica,Verdana,Arial,sans-serif;
    font-weight: 400;
    background-color: #792c1a;
  }
      tbody{
    color:white;
  }
  .fclo{
    color: #ffdb0d;
  }
  .add{
    text-decoration: none;
    float: right;
    margin: 6px;
    padding: 8px;
  margin-top: 20px;
  background: transparent;
  border-radius: 5px;
  box-shadow: 0 0 4px #f1e186;
  cursor: pointer;
  width:auto;
  color: #000000;
  background-color:  #ffdb0d;
  }
  .card1{
   border: 3px solid #792c1a;
  border-radius: 5px;
    border-collapse: collapse;
    width: 100%;
    padding: 20px;
    margin-top: 20px;
  }
  .pamagat{
    font-size: 30px;
    font-family: helvetica,Verdana,Arial,sans-serif;
    font-weight: 400;
  color: black;
  text-decoration: underline;
  }
  .subs{
     margin-left:230px;
  margin-right: 20px;
    padding: 40px;
    margin-top: 10px;
  }
  #subjAc a{
  text-decoration: none;
  margin: 3px;
  border: 1px solid #f1e186;
  padding: 4px;
  background: transparent;
  border-radius: 4px;
  cursor: pointer;
  position:relative;
  left: 30px;
  width:auto;
  color: #000000;
  font-weight: bold;
  background-color:  #ffdb0d;
  }


  .good{
		width:30px;
		left:345px;
		top:278px;
		position: absolute; 
	}

    .bad{
		width:30px;
		left:665px;
		top:278px;
		position: absolute;
        
	}
    .neutral{
		width:30px;
		left:978px;
		top:278px;
		position: absolute;
        
	}



</style>




<div class="pamagat">Sentiment Results</div>

	<div class="card1" >
				<!-- <a class="add btn-block btn-sm btn-default btn-flat border-primary" href="./index.php?page=new_faculty"><i class="fa fa-plus"></i> Add New Faculty</a> -->
		<div class="card-body">
			<table class="table tabe-hover table-bordered" id="list">
				<thead class="fclo">
					<tr>
						<th>Good Comments</th>
                        <img class="good"src="./images/good.png">
						<th>Bad Comments</th>
                        <img class="bad"src="./images/bad.png">
						<th>Neutral Comments</th>
                        <img class="neutral"src="./images/neutral.png">
					</tr>


				</thead>
				<tbody>
					<?php
					$i = 1;
					$qry = $conn->query("SELECT *,concat(firstname,' ',lastname) as name FROM faculty_list order by concat(firstname,' ',lastname) asc");
					while($row= $qry->fetch_assoc()):
					?>
					
				<?php endwhile; ?>
				</tbody>
			</table>
		</div>
	</div>
</div>
<script>
	$(document).ready(function(){
	$('.view_faculty').click(function(){
		uni_modal("<i class='fa fa-id-card'></i> Faculty Details","<?php echo $_SESSION['login_view_folder'] ?>view_faculty.php?id="+$(this).attr('data-id'))
	})
	$('.delete_faculty').click(function(){
	_conf("Are you sure to restore this faculty?","delete_faculty",[$(this).attr('data-id')])
	})
		$('#list').dataTable()
	})
	function delete_faculty($id){
		start_load()
		$.ajax({
			url:'ajax.php?action=delete_faculty',
			method:'POST',
			data:{id:$id},
			success:function(resp){
				if(resp==1){
					alert_toast("Data successfully deleted",'success')
					setTimeout(function(){
						location.reload()
					},1500)

				}
			}
		})
	}
</script>

<?php include('db_connect.php'); ?>
<?php 

function ordinal_suffix1($num){
    $num = $num % 100; // protect against large numbers
    if($num < 11 || $num > 13){
         switch($num % 10){
            case 1: return $num.'st';
            case 2: return $num.'nd';
            case 3: return $num.'rd';
        }
    }
    return $num.'th';
}
$astat = array("Not Yet Started","On-going","Closed");
 ?>


 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="./css/home.css">
 <div class="home">

 <style>
@import url('https://fonts.googleapis.com/css2?family=Comfortaa:wght@500&display=swap');
@import url('https://fonts.googleapis.com/css2?family=Comfortaa:wght@500&family=Special+Elite&display=swap');
.home{
	margin-top: 30px;
	font-family: helvetica,Verdana,Arial,sans-serif;
    font-weight: 400;


}
.heading{
	font-size: 15px;
	margin-right:170px;
	font-family: helvetica,Verdana,Arial,sans-serif;
  font-weight: 400;
	float: right;	

}
.row{
	border: 5px solid #792c1a;
    background: transparent;
    border-radius: 10px;
	margin-left:300px;
	background-color: #814827;
	margin-right:150px;
	padding:70px;
	width:auto;
	font-family: helvetica,Verdana,Arial,sans-serif;
  font-weight: 400;
	content:"";
	display: table;
	clear: both;
	box-shadow: #792c1a;

	 
}
.wcpo{
	font-size: 30px;
	border-bottom:  1px solid #ececec;
	font-family: helvetica,Verdana,Arial,sans-serif;
	color: #ececec;
    font-weight: 400;
}
.column{
	border: solid black;
	border-top: hidden;
	border-left: hidden;
	margin-left:30px;
	margin-left:30px;
	margin-top: 20px;
	padding: 50px;
	border-radius: 5px;
	float:left;
  	width: auto;
  	border-color:#ffdb0d;

}
.column p{
	font-size: 30px;
	 font-family: 'Comfortaa', cursive;
  	color: #ffdb0d;
  	font-weight: bolder;
}
.column h3{
	border-top: 7px;
	font-size: 18px;
	font-family: helvetica,Verdana,Arial,sans-serif;
    font-weight: 400;
  	color: #ececec;
}





#footer {
	background: #ffdb0d;
	padding-top: 0x;
	padding-bottom: 0px;
	border-color: #792c1a;
	margin-top: 20px;
	box-sizing: border-box;
	margin: 0;
  }
  
  
  #footer p {
	font-size: 11px;
	letter-spacing: 0.1em;
	margin-top: 0;
	margin: 0;
	text-align: center;
	text-transform: uppercase;
	font-family: helvetica,Verdana,Arial,sans-serif;
    font-weight: 400;

  }
  
  .credits {
	position: relative;
	bottom: 20px;
	font-size: 20px;
	text-align: center;
	margin: 0;
	font-family: helvetica,Verdana,Arial,sans-serif;
    font-weight: 400;
	padding-top: 20px;
  }



  #footer .socials-media ul li {
    margin-right: 0;
	margin: 0;
    margin-left: 0;
    float: none;
    display: inline-block;
  }
   </style>
 <div class="heading">
        <div class="col-md-5">
          <div class="callout callout-info">
            <h1>Status of Evaluation: <?php echo $astat[$_SESSION['academic']['status']] ?></h1>  
            <h1>Academic Year: <?php echo $_SESSION['academic']['year'].' '.(ordinal_suffix1($_SESSION['academic']['semester'])) ?> Semester</h1>
            
          </div>
        </div>
     
</div>
        <div class="row">
          <p class="wcpo"> Welcome <?php echo ucwords($_SESSION['login_firstname']) ?>, Have a Nice Day!</p>
          <div class="column">
            
              <p>STUDENTS</p>
                <h3><?php echo $conn->query("SELECT * FROM student_list")->num_rows; ?></h3>
                
              
          </div>
           <div class="column">
            
                

               <p>FACULTIES</p>
                <h3><?php echo $conn->query("SELECT * FROM faculty_list ")->num_rows; ?></h3>
              
          </div>
           <div class="column">
           
                 <p>CLASSES</p>
                <h3><?php echo $conn->query("SELECT * FROM class_list")->num_rows; ?></h3>

             
          </div>
          <div class="column">
              
                

                
                <p>ADMINS</p>
                 <h3><?php echo $conn->query("SELECT * FROM users")->num_rows; ?></h3>
              
          </div>
      </div>
      <br>
      <br>
      <div id="footer" class="text-center">
        <div class="container">
          <div class="socials-media text-center">
    
            <ul class="list-unstyled">
              <li><a href="twitter.com"><i class="ion-social-twitter"></i></a></li>
              <li><a href="instagram.com"><i class="ion-social-instagram"></i></a></li>
            </ul>
    
          </div>
    
          
          <div class="credits">
            Pambayang Dalubhasaan ng Marilao
            <p>2021 All Rights Reserved.</p>
            <p>
              <br><a href="https://www.edukasyon.ph/schools/pambayang-dalubhasaan-ng-marilao">www.edukasyon.ph/schools/pambayang-dalubhasaan-ng-marilao</p></a>
          </div>
    </div>
    </div>
